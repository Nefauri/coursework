import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.beans.binding.Bindings;
import javafx.scene.control.Slider;

import javafx.scene.media.*;
import javafx.scene.image.*;
import javafx.beans.binding.*;
import javafx.beans.property.*;
import javafx.beans.value.*;
import javafx.collections.*;
import javafx.util.*;
import javafx.beans.binding.Bindings;

import java.net.*;
import java.util.*;
import java.text.DecimalFormat;
import java.lang.String.*;
import java.io.File;
import java.io.PrintWriter;
import java.io.*;
import java.net.*;
// JavaFX documentation: http://docs.oracle.com/javafx/2/api/

/**
 * @author Lee Stemkoski
 */
public class MediaApplication extends Application 
{
    boolean isPlay = false;
    boolean firstplay = true;
    boolean isrepeat = false;
    /**
     *   Run the application.
     *   Note: Application is a Process, only one allowed per VM.
     */
    public static void main(String[] args) 
    {
        launch(args);
    }

    @Override
    public void start(Stage theStage) 
    {
        theStage.setTitle("Media Player!");

        Group root = new Group();
        Scene theScene = new Scene(root, 450, 800);
        theScene.setFill( Color.color(.20, .20, .20) );
        //Create media view
        final MediaView mediaView = new MediaView();

        // when the size of something changes, resize the window appropriately.
        ChangeListener resizeListener = new ChangeListener()
            {
                public void changed(ObservableValue o, Object oldValue, Object newValue)
                {
                    theStage.sizeToScene();
                }
            };

        //Load up some images
        final Image blankImage = new Image("images/blankIcon.png");
        final Image stopIcon = new Image("images/stopIcon.png");
        final Image repeatIcon = new Image("images/repeatIcon.png");
        final Image previousIcon = new Image("images/previousIcon.png");
        final Image rewindIcon = new Image("images/rewindIcon.png");
        final Image playIcon = new Image("images/playIcon.png");
        final Image pauseIcon = new Image("images/pauseIcon.png");
        final Image nextIcon = new Image("images/nextIcon.png");
        final Image fastforwardIcon = new Image("images/fastforwardIcon.png");
        final Image volumeIcon = new Image("images/volumeIcon.png");
        final Image muteIcon = new Image("images/muteIcon.png");

        //Load some CSS

        try
        {
            File cssFile = new File("myStyle.css");
            URL  cssURL  = cssFile.toURI().toURL();   
            theScene.getStylesheets().clear();
            theScene.getStylesheets().add( cssURL.toString() );
        }
        catch (Exception ex)
        {
            System.out.println("Couldn't find/parse stylesheet file.");
            ex.printStackTrace();
        }

        Label artistname = LabelBuilder.create()
            .text("")
            .build();

        Label songtitle = LabelBuilder.create()
            .text("")
            .build();

        songtitle.getStyleClass().add("main");
        artistname.getStyleClass().add("main");

        //VBox
        VBox mainBox = VBoxBuilder.create()
            .padding(new Insets(30))     // space outside of this box
            .spacing(10)                 // space between box elements
            .alignment(Pos.CENTER)       // left-aligned by default
            .build();

       mainBox.getStyleClass().add("main");
            
        mainBox.prefWidthProperty().bind( theStage.widthProperty() );
        mainBox.prefHeightProperty().bind( theStage.heightProperty() );
        // Time 
        final Label currentTime = LabelBuilder.create()
            .text("")
            .alignment(Pos.CENTER)
            .build();

        // Play
        Button buttonPlay = ButtonBuilder.create()
            .graphic( new ImageView(playIcon))
                //.setBackground(null)
            .build();  

        //Transparent Button?
        buttonPlay.setStyle("-fx-background-color: transparent;");

        Label songInfo = LabelBuilder.create()
            .text("")
            .build();

        //Okay, we need an image view box for the current song icon: 
        final ImageView mainImage = new ImageView(blankImage);

        // Seek width should be as big as the image
        //The seek slider needs to be underneath this:
        Slider seekSlider = SliderBuilder.create()
            .orientation(Orientation.HORIZONTAL)
            .prefWidth(300)
            .min(0)
            .max(300)//The max will change depending on the song
            .value(0)//No song will be playing initially
            .showTickLabels(false)
            .showTickMarks(false)
            .snapToTicks(false)
            .build();

        // Volume slider
        Slider volumeSlider = SliderBuilder.create()
            .orientation(Orientation.HORIZONTAL)
            .prefWidth(250)
            .min(0)
            .max(1)//The max will change depending on the song
            .value(50)//No song will be playing initially
            .showTickLabels(false)
            .showTickMarks(false)
            .snapToTicks(false)
            .build();

        // stop, previous, play, next and repeat should go in this box
        HBox optionsBox = HBoxBuilder.create()
            .padding(new Insets(5))
            .spacing(5)
            .alignment(Pos.CENTER)
            .build();

        ChangeListener mediaListener = new ChangeListener()
            {
                public void changed(ObservableValue o, Object oldValue, Object newValue)
                {

                    if ( newValue.equals(MediaPlayer.Status.READY) )
                    {

                        try
                        {   

                            MediaPlayer mp = mediaView.getMediaPlayer();//new MediaPlayer( mediaObject );
                            if (mp != null) {
                                mediaView.setMediaPlayer( mp );
                                System.out.println(isrepeat);
                                if ((isrepeat == true) && (mp.getCurrentTime().toMillis() == mp.getStopTime().toMillis()))
                                {
                                    System.out.println("Do we get here?");
                                    mediaView.getMediaPlayer().stop();
                                    mediaView.getMediaPlayer().play();
                                }
                                System.out.println(isrepeat);
                                //If the current time is equal to the end time, and repeat is true, play the song
                                //if ((mp.getCurrentTime().toMillis() == mp.getStopTime().toMillis()) && isrepeat == true)
                                //    mp.play();
                                mp.onEndOfMediaProperty();
                                System.out.println("stem-1");

                                StringBinding timeExtractor = new StringBinding() 
                                    {
                                        {
                                            super.bind( mediaView.getMediaPlayer().currentTimeProperty());
                                        }

                                        @Override 
                                        protected String computeValue() {
                                            MediaPlayer mp = mediaView.getMediaPlayer();	
                                            System.out.println(isrepeat);
                                            System.out.println("In time extractor section");
                                            System.out.println(Math.abs(mp.getCurrentTime().toMillis() - mp.getStopTime().toMillis()) <= 100.0);
                                            System.out.println(mp.getCurrentTime().toMillis());
                                            System.out.println(mp.getStopTime().toMillis());
                                            if ((isrepeat == true) && ( Math.abs(mp.getCurrentTime().toMillis() - mp.getStopTime().toMillis()) <= 100.0)   )
                                            {
                                                System.out.println("Do we get here?");
                                                mediaView.getMediaPlayer().stop();
                                                mediaView.getMediaPlayer().play();
                                            }

                                            double miliseconds = mp.getCurrentTime().toMillis();
                                            double endMiliseconds = mp.getStopTime().toMillis();

                                            int minutes= (int)((miliseconds/1000)/60);
                                            int seconds=(int)((miliseconds/1000)%60);

                                            int endMinutes = (int) ((endMiliseconds/1000)/60);
                                            int endSeconds = (int) ((endMiliseconds/1000)%60);

                                            return  minutes + ":" + seconds +"/" + endMinutes + ":" + endSeconds;
                                        }
                                    };
                                currentTime.textProperty().bind( timeExtractor ); 

                                System.out.println("stem-2");

                                DoubleBinding updateSlide = new DoubleBinding() 
                                    {
                                        {
                                            super.bind( mediaView.getMediaPlayer().currentTimeProperty());
                                        }

                                        @Override 
                                        protected double computeValue() {

                                            MediaPlayer mp = mediaView.getMediaPlayer();
                                            System.out.println(mp.getCurrentTime().toMillis());
                                            return mp.getCurrentTime().toMillis();
                                        }
                                    };
                                seekSlider.valueProperty().bind( updateSlide );

                                System.out.println("stem-3");

                                seekSlider.setMax(mp.getStopTime().toMillis());
                                String songText = "";
                                String artistText = "";
                                Map<String,Object> m = mediaView.getMediaPlayer().getMedia().getMetadata();

                                System.out.println("stem-4");

                                String test = (String)m.get("title");
                                System.out.println("TITLE" + test);

                                for ( Map.Entry<String, Object> e : m.entrySet() ) 
                                {
                                    System.out.println(e.getValue());
                                    if ((e.getKey().compareTo("title") == 0) || (e.getKey().compareTo("artist") == 0)) {
                                        songText = e.getValue() +"";
                                        System.out.println(e.getValue());
                                    }
                                    
                                    if (e.getKey().compareTo("artist") == 0) {
                                        artistText = e.getValue()+"";
                                        System.out.println(e.getValue());
                                    }

                                    if (e.getKey().compareTo("image") == 0) {

                                    }
                                }
                                //System.out.println(infoText);                                         
                                songtitle.setText(songText);
                                artistname.setText(artistText);
                            }
                        }
                        catch (Exception ex)
                        {
                            ex.printStackTrace();
                        }

                    }
                }
            };     

        // Repeat button:
        Button buttonRepeat = ButtonBuilder.create()
            .graphic( new ImageView(repeatIcon))
            .onAction( new EventHandler<ActionEvent>()
                {
                    @Override
                    public void handle(ActionEvent event)
                    {
                        System.out.println("Repeat!");
                        MediaPlayer mp = mediaView.getMediaPlayer();
                        if (mp != null){
                            if (isrepeat == false) { 
                                mp.setCycleCount(1);
                                isrepeat = true;
                                System.out.println(isrepeat);
                                System.out.println("We are repeating!");

                            } else if (isrepeat == true) { 
                                mp.setCycleCount(0);
                                isrepeat = false;
                                System.out.println(isrepeat);
                                System.out.println("We are not!");
                            }
                        }
                    }

                })
            .build();
        buttonRepeat.setStyle("-fx-background-color: transparent;");    

        // Previous
        Button buttonPrevious = ButtonBuilder.create()
            .graphic( new ImageView(previousIcon))
            .onAction( new EventHandler<ActionEvent>()
                {
                    @Override
                    public void handle(ActionEvent event)
                    {                        
                        MediaPlayer mp = mediaView.getMediaPlayer();
                        if (mp != null) {
                            double currentTime = mp.getCurrentTime().toMillis();
                            double rewindAmount = 1000;                   

                            double newCurrentTime = currentTime - rewindAmount;
                            if (newCurrentTime >= 0.0 && newCurrentTime <= mp.getStopTime().toMillis()) 
                            {
                                Duration seekDuration = new Duration(newCurrentTime);
                                mp.seek( seekDuration );              
                            }
                        }
                    }
                })
            .build();  
        buttonPrevious.setStyle("-fx-background-color: transparent;");

        EventHandler<ActionEvent> play1 = new EventHandler<ActionEvent>()
            {
                @Override
                public void handle(ActionEvent event)
                {
                    if (mediaView.getMediaPlayer() == null) 
                        return;

                    if (isPlay == false) {
                        buttonPlay.setGraphic(new ImageView(pauseIcon));
                        mediaView.getMediaPlayer().play();
                        System.out.println("Playing!");
                        isPlay = true;

                    } else {
                        buttonPlay.setGraphic(new ImageView(playIcon));
                        mediaView.getMediaPlayer().pause();
                        System.out.println("Paused");
                        isPlay = false;
                    }
                    System.out.println(mediaView.getMediaPlayer().currentTimeProperty());
                    System.out.println("Play");
                }
            };
        buttonPlay.setOnAction( play1 );

        // Fast-Forward
        Button buttonNext = ButtonBuilder.create()
            .graphic( new ImageView(nextIcon))
            .onAction( new EventHandler<ActionEvent>()
                {
                    @Override
                    public void handle(ActionEvent event)
                    {
                        MediaPlayer mp = mediaView.getMediaPlayer();
                        if (mp != null) {
                            double currentTime = mp.getCurrentTime().toMillis();
                            double fastforwardAmount = 1000;                   

                            double newCurrentTime = currentTime + fastforwardAmount;
                            if (newCurrentTime >= 0.0 && newCurrentTime <= mp.getStopTime().toMillis()) 
                            {    
                                Duration seekDuration = new Duration(newCurrentTime);
                                mp.seek( seekDuration );  
                            }
                        }
                    }
                })
            .build();      
        buttonNext.setStyle("-fx-background-color: transparent;");
        // Stop
        Button buttonStop = ButtonBuilder.create()
            .graphic( new ImageView(stopIcon))
            .onAction( new EventHandler<ActionEvent>()
                {
                    @Override
                    public void handle(ActionEvent event)
                    {
                        if (mediaView.getMediaPlayer() != null) {
                            mediaView.getMediaPlayer().stop();
                            buttonPlay.setGraphic(new ImageView(playIcon));
                            isPlay = false;
                            DoubleBinding updateSlide_1 = new DoubleBinding() 
                                {
                                    {
                                        super.bind( mediaView.getMediaPlayer().currentTimeProperty());
                                    }

                                    @Override 
                                    protected double computeValue() {
                                        MediaPlayer mp = mediaView.getMediaPlayer();
                                        return mp.getCurrentTime().toMillis();
                                    }
                                };
                            seekSlider.valueProperty().bind( updateSlide_1 );

                            System.out.println("Stop!");
                        }
                    }
                })
            .build();
        buttonStop.setStyle("-fx-background-color: transparent;");

        // Hbox:
        HBox tv = HBoxBuilder.create()
            .padding(new Insets(10))
            .spacing(20)
            .alignment(Pos.CENTER)
            .build();
        //Button for volume

        Button buttonVolume = ButtonBuilder.create()
            .graphic( new ImageView(volumeIcon))
            .onAction( new EventHandler<ActionEvent>()
                {
                    @Override
                    public void handle(ActionEvent event)
                    {
                        System.out.println("Volume!");
                    }
                })
            .build();
        buttonVolume.setStyle("-fx-background-color: transparent;");
        //Event for mute:
        EventHandler<ActionEvent> mute1 = new EventHandler<ActionEvent>()
            {
                @Override
                public void handle(ActionEvent event)
                {
                    if (mediaView.getMediaPlayer() != null) {
                        boolean currentlyMuted = mediaView.getMediaPlayer().isMute();
                        if (currentlyMuted == false)
                            buttonVolume.setGraphic(new ImageView(muteIcon));
                        else 
                            buttonVolume.setGraphic(new ImageView(volumeIcon));
                        mediaView.getMediaPlayer().setMute( !currentlyMuted );
                    }
                }
            };            
        buttonVolume.setOnAction(mute1);

        EventHandler <ActionEvent> rewind = new EventHandler<ActionEvent>()
            {
                @Override
                public void handle(ActionEvent event)
                {
                    MediaPlayer mp = mediaView.getMediaPlayer();
                    if (mp != null) {
                        double currentTime = mp.getCurrentTime().toMillis();
                        double rewindAmount = 0.1;                   

                        double newCurrentTime = currentTime - 0.1;
                        if (newCurrentTime >= 0.0 && newCurrentTime <= mp.getStopTime().toMillis()) 
                        {
                            Duration seekDuration = new Duration(newCurrentTime);
                            mp.seek( seekDuration );              
                        }
                    }
                }
            };

        EventHandler <ActionEvent> fastforward = new EventHandler<ActionEvent>()
            {
                @Override
                public void handle(ActionEvent event)
                {
                    MediaPlayer mp = mediaView.getMediaPlayer();
                    if (mp != null) {
                        double currentTime = mp.getCurrentTime().toMillis();
                        double fastforwardAmount = 0.1;                   

                        double newCurrentTime = currentTime + 0.1;
                        if (newCurrentTime >= 0.0 && newCurrentTime <= mp.getStopTime().toMillis()) 
                        {    
                            Duration seekDuration = new Duration(newCurrentTime);
                            mp.seek( seekDuration );  
                        }
                    }
                }
            };

        // Event for volume slide

        volumeSlider.valueProperty().addListener(
            new ChangeListener()
            {
                public void changed(ObservableValue o, Object oldValue, Object newValue)
                {
                    if (mediaView.getMediaPlayer() != null) {
                        double newVol = (Double)newValue;
                        mediaView.getMediaPlayer().setVolume(newVol);
                    }
                }
            });                      

        // code -------------------------------------------------
        // MENU SECTION ----------------------------------

        MenuBar menuBar = new MenuBar();
        menuBar.prefWidthProperty().bind( theStage.widthProperty() );
        //menuBar.setFill( Color.color(.26, .26, .26) );
        // FILE MENU -------------------------------------
        final FileChooser fileChooser = new FileChooser();
        Menu menuFile = new Menu("File");

        MenuItem menuItemOpen = MenuItemBuilder.create()
            .text("Open")
            .onAction( new EventHandler<ActionEvent>()
                {
                    public void handle(ActionEvent event)
                    {
                        try 
                        {
                            File f = fileChooser.showOpenDialog(theStage);

                            if (f == null) 
                                return;

                            File        NewMediaFile   = new File(f.getAbsolutePath());
                            // File        mediaFile   = new File("media/speedrun.mp4");
                            URL mediaURL    = NewMediaFile.toURI().toURL();
                            System.out.println("We made it to the new media file part" + mediaURL);
                            Media mediaObject = new Media( mediaURL.toString());
                            MediaPlayer mp = new MediaPlayer( mediaObject );

                            mp.statusProperty().addListener( mediaListener );
                            mediaView.setMediaPlayer( mp );
                            seekSlider.setMax(mp.getStopTime().toMillis());
                            String info = "";
                            Map<String,Object> m = mediaView.getMediaPlayer().getMedia().getMetadata();
                            for ( Map.Entry<String, Object> e : m.entrySet() ) 
                            {
                                if ((e.getKey().compareTo("title") == 0) || (e.getKey().compareTo("artist") == 0)) {
                                    info += e.getValue() +"\n";
                                    System.out.println(e.getValue());
                                }
                            }

                            songtitle.setText(info + "Are you seeing this");
                        } 
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                })
            .build();

        menuFile.getItems().addAll(
            menuItemOpen);

        menuBar.getMenus().add(menuFile);
        // current time properties

        //Also need to bind the slider to this value

        // code -------------------------------------------------

        optionsBox.getChildren().addAll( buttonRepeat, buttonPrevious,buttonPlay,buttonNext, buttonStop);
        tv.getChildren().addAll(buttonVolume, volumeSlider, currentTime);
        mainBox.getChildren().addAll(mainImage, artistname, songtitle, optionsBox, tv, seekSlider);
        //

        root.getChildren().add(mainBox);
        root.getChildren().add(menuBar);
        theStage.setScene(theScene);
        theStage.show();
    }
}
